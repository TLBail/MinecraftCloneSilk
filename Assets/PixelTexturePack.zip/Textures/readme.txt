Credit "Jestan", appreciated but not necessary.

Support my work:
https://ko-fi.com/jestan